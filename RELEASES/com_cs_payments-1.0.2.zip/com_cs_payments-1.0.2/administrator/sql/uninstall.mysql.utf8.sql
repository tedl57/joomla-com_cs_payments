DROP TABLE IF EXISTS `#__cs_payments`;
DROP TABLE IF EXISTS `#__cs_donation_funds`;
DROP TABLE IF EXISTS `#__cs_membership_types`;
DROP TABLE IF EXISTS `#__cs_sources`;
